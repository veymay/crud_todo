let todoAddInput = document.querySelector('.todo_add>input'),
  todoList = document.querySelector('.todo_list'),
todos = []

function setStorage(key,value) {
  localStorage.setItem(key,JSON.stringify(value))
}
function getStorage(key) {
  JSON.parse(localStorage.getItem(key)).forEach(task => {
    return task
  });
}
function addItem(task) {
  todoList.innerHTML += `<li>${task}</li>`
}

document.addEventListener('keydown', (e) => {
  todoAddInput.focus()
  if (e.key=='Enter') {
    todos.push({ text: todoAddInput.value })
    setStorage('taskList', todos)
    console.log(getStorage('tasklist'));
  }
})
