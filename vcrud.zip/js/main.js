let todoInp = document.querySelector('.todo_input')
let todoList = document.querySelector('ul.todo_list')


let todos = JSON.parse(localStorage.getItem('todosLIST')) ? JSON.parse(localStorage.getItem('todosLIST')) : []

function setTODO() {
  todos.push(todoInp.value)
  todoInp.value = ''
  localStorage.setItem('todosLIST', JSON.stringify(todos))
}
function getTODO() {
  todoList.innerHTML = ''
  todos.forEach((todo, id) => {
    todoList.innerHTML += `
    <li class='item'>
    <div class="content">${todo}</div>
    <div class="buttons">
    <span class="edit" onclick="editTODO(${id})">
    <i class="fi fi-br-pencil"></i>
    </span >
    <span class="remove" onclick="delTODO(${id})">
    <i class="fi fi-br-cross"></i>
    </span >
    </div >
    </li > `
  });
}

function editTODO(id) {
  let todoListItems = document.querySelectorAll('ul.todo_list>li')
  todoListItems[id].setAttribute('contenteditable', 'true')
  // localStorage.setItem('todosLIST', JSON.stringify(todos))
  // getTODO()
}
function delTODO(id) {
  todos.splice(id, 1);
  getTODO()
  localStorage.setItem('todosLIST', JSON.stringify(todos))
}
document.addEventListener('keydown', (e) => {
  // todoInp.focus()
  if (e.key == 'Enter') {
    setTODO()
    getTODO()
  }
})

getTODO()